package fyp.tayxinyu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Fyp2Application {

	public static void main(String[] args) {
		SpringApplication.run(Fyp2Application.class, args);
	}

}
